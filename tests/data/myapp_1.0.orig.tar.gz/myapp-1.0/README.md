This directory contains various files used by the testsuite.
